import { useEffect } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
  type PressableProps,
  type ViewStyle,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import Animated, {
  Easing,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { colors, fonts, gradients, motion, radii, shadows, spacing } from '@/src/theme/tokens';

interface PrimaryButtonProps extends PressableProps {
  label: string;
  variant?: 'gold' | 'ocean' | 'coral' | 'ghost' | 'primary' | 'secondary' | 'danger';
  style?: ViewStyle;
  loading?: boolean;
  icon?: React.ReactNode;
}

const VARIANT_GRADIENT: Record<string, readonly [string, string, string]> = {
  gold: gradients.gold,
  primary: gradients.gold,
  ocean: gradients.ocean,
  coral: gradients.coral,
  danger: gradients.error,
};

const VARIANT_GLOW = {
  gold: shadows.glowGold,
  primary: shadows.glowGold,
  ocean: shadows.glowOcean,
  coral: shadows.glowCoral,
  danger: shadows.glowCoral,
  ghost: undefined,
  secondary: undefined,
};

export function PrimaryButton({
  label,
  variant = 'gold',
  style,
  loading,
  disabled,
  icon,
  onPress,
  ...props
}: PrimaryButtonProps) {
  const scale = useSharedValue(1);
  const shine = useSharedValue(-1);
  const isGhost = variant === 'ghost' || variant === 'secondary';

  useEffect(() => {
    shine.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 2200, easing: Easing.inOut(Easing.ease) }),
        withTiming(1, { duration: 1600 }),
        withTiming(-1, { duration: 0 })
      ),
      -1
    );
  }, [shine]);

  const containerStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const shineStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: interpolate(shine.value, [-1, 1], [-140, 220]) }, { rotate: '18deg' }],
  }));

  const isDisabled = disabled || loading;

  return (
    <Pressable
      disabled={isDisabled}
      onPressIn={() => {
        scale.value = withSpring(0.96, motion.spring.press);
      }}
      onPressOut={() => {
        scale.value = withSpring(1, motion.spring.bouncy);
      }}
      onPress={(e) => {
        void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        onPress?.(e);
      }}
      {...props}
    >
      <Animated.View
        style={[
          styles.base,
          containerStyle,
          isGhost ? styles.ghost : VARIANT_GLOW[variant],
          isDisabled && styles.disabled,
          style,
        ]}
      >
        {isGhost ? (
          <View style={[StyleSheet.absoluteFill, styles.ghostFill]} />
        ) : (
          <LinearGradient
            colors={VARIANT_GRADIENT[variant] ?? gradients.gold}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        )}
        {!isGhost && !isDisabled ? (
          <View style={styles.shineMask} pointerEvents="none">
            <Animated.View style={[styles.shine, shineStyle]} />
          </View>
        ) : null}

        <View style={styles.content}>
          {loading ? (
            <ActivityIndicator color={isGhost ? colors.text : colors.background} />
          ) : (
            <>
              {icon}
              <Text style={[styles.label, isGhost ? styles.labelGhost : styles.labelOnFill]}>
                {label}
              </Text>
            </>
          )}
        </View>
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    borderRadius: radii.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  ghost: {
    borderWidth: 1.5,
    borderColor: colors.borderLight,
  },
  ghostFill: {
    backgroundColor: colors.surfaceElevated,
  },
  disabled: {
    opacity: 0.5,
  },
  shineMask: {
    ...StyleSheet.absoluteFill,
    overflow: 'hidden',
  },
  shine: {
    position: 'absolute',
    top: -40,
    width: 50,
    height: 140,
    backgroundColor: 'rgba(255,255,255,0.35)',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  label: {
    fontFamily: fonts.bodyBold,
    fontSize: 16,
  },
  labelOnFill: {
    color: colors.background,
  },
  labelGhost: {
    color: colors.text,
  },
});
