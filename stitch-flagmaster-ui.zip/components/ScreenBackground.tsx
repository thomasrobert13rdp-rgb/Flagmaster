import { useEffect } from 'react';
import { StyleSheet, View, useWindowDimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle, Defs, Path, RadialGradient, Stop } from 'react-native-svg';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import { colors, gradients } from '@/src/theme/tokens';

const AnimatedCircle = Animated.createAnimatedComponent(View);

interface ScreenBackgroundProps {
  children?: React.ReactNode;
  variant?: 'default' | 'gold' | 'coral';
}

/**
 * Shared "night map" backdrop: deep gradient + slow-drifting aurora blobs
 * + a faint topographic contour-line watermark, used behind every screen.
 */
export function ScreenBackground({ children, variant = 'default' }: ScreenBackgroundProps) {
  const { width, height } = useWindowDimensions();
  const drift = useSharedValue(0);

  useEffect(() => {
    drift.value = withRepeat(
      withTiming(1, { duration: 9000, easing: Easing.inOut(Easing.sin) }),
      -1,
      true
    );
  }, [drift]);

  const blobA = useAnimatedStyle(() => ({
    transform: [
      { translateX: drift.value * 30 - 15 },
      { translateY: drift.value * -24 + 12 },
    ],
  }));
  const blobB = useAnimatedStyle(() => ({
    transform: [
      { translateX: drift.value * -26 + 13 },
      { translateY: drift.value * 20 - 10 },
    ],
  }));

  const secondaryGradient =
    variant === 'gold' ? gradients.auroraGold : variant === 'coral' ? gradients.auroraCoral : gradients.auroraGold;

  return (
    <View style={styles.root}>
      <LinearGradient colors={gradients.background} style={StyleSheet.absoluteFill} />

      <Svg width={width} height={height} style={StyleSheet.absoluteFill} pointerEvents="none">
        <Path
          d={topoPath(width, height * 0.28)}
          stroke={colors.borderLight}
          strokeWidth={1}
          fill="none"
          opacity={0.16}
        />
        <Path
          d={topoPath(width, height * 0.62)}
          stroke={colors.borderLight}
          strokeWidth={1}
          fill="none"
          opacity={0.1}
        />
      </Svg>

      <AnimatedCircle style={[styles.blob, styles.blobTop, blobA]}>
        <Svg width={280} height={280}>
          <Defs>
            <RadialGradient id="auroraTeal" cx="50%" cy="50%" r="50%">
              <Stop offset="0%" stopColor={gradients.auroraTeal[0]} />
              <Stop offset="100%" stopColor={gradients.auroraTeal[1]} />
            </RadialGradient>
          </Defs>
          <Circle cx={140} cy={140} r={140} fill="url(#auroraTeal)" />
        </Svg>
      </AnimatedCircle>

      <AnimatedCircle style={[styles.blob, styles.blobBottom, blobB]}>
        <Svg width={320} height={320}>
          <Defs>
            <RadialGradient id="auroraSecondary" cx="50%" cy="50%" r="50%">
              <Stop offset="0%" stopColor={secondaryGradient[0]} />
              <Stop offset="100%" stopColor={secondaryGradient[1]} />
            </RadialGradient>
          </Defs>
          <Circle cx={160} cy={160} r={160} fill="url(#auroraSecondary)" />
        </Svg>
      </AnimatedCircle>

      <View style={styles.content}>{children}</View>
    </View>
  );
}

function topoPath(width: number, baseY: number): string {
  const amp = 26;
  const step = width / 6;
  let d = `M 0 ${baseY}`;
  for (let i = 1; i <= 6; i += 1) {
    const x = step * i;
    const y = baseY + (i % 2 === 0 ? amp : -amp);
    const cx = x - step / 2;
    d += ` Q ${cx} ${y} ${x} ${baseY}`;
  }
  return d;
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { flex: 1 },
  blob: { position: 'absolute' },
  blobTop: { top: -60, right: -60 },
  blobBottom: { bottom: -40, left: -80 },
});
