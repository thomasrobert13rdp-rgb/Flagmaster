import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { colors, fonts, motion, radii, spacing } from '@/src/theme/tokens';

const ICONS: Record<string, keyof typeof FontAwesome.glyphMap> = {
  book: 'book',
  heart: 'heart',
  bolt: 'bolt',
  road: 'road',
  'clock-o': 'clock-o',
  map: 'map-o',
  flag: 'flag',
  star: 'star',
  repeat: 'repeat',
  eye: 'eye',
};

interface FormatCardProps {
  title: string;
  description: string;
  icon: string;
  gradient: readonly [string, string, string];
  record?: number;
  recordLabel?: string;
  fullWidth?: boolean;
  selected?: boolean;
  onPress: () => void;
}

export function FormatCard({
  title,
  description,
  icon,
  gradient,
  record,
  recordLabel,
  fullWidth,
  selected,
  onPress,
}: FormatCardProps) {
  const faIcon = ICONS[icon] ?? 'book';
  const scale = useSharedValue(1);
  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <Pressable
      style={[styles.wrap, fullWidth && styles.wrapFull]}
      onPress={onPress}
      onPressIn={() => {
        scale.value = withSpring(0.96, motion.spring.press);
      }}
      onPressOut={() => {
        scale.value = withSpring(1, motion.spring.press);
      }}
    >
      <Animated.View style={[styles.cardWrap, selected && styles.cardWrapSelected, animatedStyle]}>
        <LinearGradient colors={gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.card}>
          <View style={styles.cardTop}>
            <FontAwesome name={faIcon} size={24} color={colors.background} />
            {selected ? (
              <View style={styles.checkBadge}>
                <FontAwesome name="check" size={11} color={colors.text} />
              </View>
            ) : null}
          </View>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.desc}>{description}</Text>
          {record !== undefined && record > 0 ? (
            <View style={styles.recordChip}>
              <Text style={styles.recordText}>
                {recordLabel}: {record}
              </Text>
            </View>
          ) : null}
        </LinearGradient>
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrap: { width: '48%' },
  wrapFull: { width: '100%' },
  cardWrap: {
    borderRadius: radii.lg,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  cardWrapSelected: {
    borderColor: colors.text,
    shadowColor: colors.coral,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45,
    shadowRadius: 12,
    elevation: 6,
  },
  card: {
    borderRadius: radii.lg - 2,
    padding: spacing.md,
    minHeight: 120,
    justifyContent: 'space-between',
    gap: spacing.xs,
  },
  cardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  checkBadge: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(8,11,24,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { fontFamily: fonts.displayMedium, fontSize: 15, color: colors.background },
  desc: { fontFamily: fonts.bodyMedium, fontSize: 11, color: 'rgba(8,11,24,0.75)' },
  recordChip: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(8,11,24,0.25)',
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: radii.full,
    marginTop: spacing.xs,
  },
  recordText: { fontFamily: fonts.bodyBold, fontSize: 10, color: colors.background },
});
