import { useEffect } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { FlagImage } from '@/src/components/FlagImage';
import { colors, fonts, gradients, radii, spacing } from '@/src/theme/tokens';
import { useGameStore } from '@/src/store/gameStore';

interface QuizOptionButtonProps {
  optionId: string;
  label: string;
  asset?: string;
  showLabel?: boolean;
  selected?: boolean;
  revealed?: boolean;
  correct?: boolean;
  onPress: () => void;
  disabled?: boolean;
}

export function QuizOptionButton({
  label,
  asset,
  showLabel = true,
  selected,
  revealed,
  correct,
  onPress,
  disabled,
}: QuizOptionButtonProps) {
  const hapticsEnabled = useGameStore((s) => s.settings.hapticsEnabled);
  const scale = useSharedValue(1);
  const shake = useSharedValue(0);

  const isRightAnswer = revealed && correct;
  const isWrongPick = revealed && selected && !correct;

  useEffect(() => {
    if (isRightAnswer) {
      scale.value = withSequence(
        withSpring(1.05, { damping: 8, stiffness: 260 }),
        withSpring(1, { damping: 10, stiffness: 220 })
      );
    } else if (isWrongPick) {
      shake.value = withSequence(
        withTiming(-6, { duration: 45 }),
        withTiming(6, { duration: 45 }),
        withTiming(-4, { duration: 45 }),
        withTiming(0, { duration: 45 })
      );
    }
  }, [isRightAnswer, isWrongPick, scale, shake]);

  const handlePress = () => {
    if (disabled) return;
    if (hapticsEnabled) {
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onPress();
  };

  let borderColor: string = colors.border;
  let fillGradient: readonly [string, string, string] | null = null;

  if (revealed) {
    if (correct) {
      borderColor = colors.success;
      fillGradient = gradients.success;
    } else if (selected) {
      borderColor = colors.error;
      fillGradient = gradients.error;
    }
  } else if (selected) {
    borderColor = colors.primary;
  }

  const flagOnly = Boolean(asset) && !showLabel;

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }, { translateX: shake.value }],
  }));

  return (
    <Pressable onPress={handlePress} disabled={disabled}>
      <Animated.View
        style={[
          styles.option,
          flagOnly && styles.optionFlagOnly,
          { borderColor },
          animatedStyle,
        ]}
      >
        {fillGradient ? (
          <LinearGradient
            colors={fillGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        ) : (
          <View style={[StyleSheet.absoluteFill, styles.defaultFill]} />
        )}

        {asset ? (
          <FlagImage asset={asset} width={flagOnly ? 140 : 80} height={flagOnly ? 92 : 54} />
        ) : null}
        {showLabel && label ? (
          <Text style={[styles.label, fillGradient && styles.labelOnFill]}>{label}</Text>
        ) : null}
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  option: {
    borderWidth: 1.5,
    borderRadius: radii.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    overflow: 'hidden',
  },
  optionFlagOnly: {
    justifyContent: 'center',
    paddingVertical: spacing.lg,
  },
  defaultFill: {
    backgroundColor: colors.surfaceElevated,
  },
  label: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    color: colors.text,
    flex: 1,
  },
  labelOnFill: {
    color: colors.background,
    fontFamily: fonts.bodyBold,
  },
});
