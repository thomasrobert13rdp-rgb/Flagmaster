import { StyleSheet, Text, View } from 'react-native';
import { colors, fonts, radii, spacing } from '@/src/theme/tokens';

interface SoloScoreChipProps {
  label: string;
  value: string | number;
  accent?: 'gold' | 'ocean' | 'coral';
}

const ACCENT_BG = {
  gold: 'rgba(245,185,66,0.15)',
  ocean: 'rgba(27,200,232,0.15)',
  coral: 'rgba(255,107,107,0.15)',
};

const ACCENT_COLOR = {
  gold: colors.gold,
  ocean: colors.primary,
  coral: colors.coral,
};

export function SoloScoreChip({ label, value, accent = 'ocean' }: SoloScoreChipProps) {
  return (
    <View style={[styles.chip, { backgroundColor: ACCENT_BG[accent] }]}>
      <Text style={styles.label}>{label}</Text>
      <Text style={[styles.value, { color: ACCENT_COLOR[accent] }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radii.md,
    alignItems: 'center',
    minWidth: 72,
  },
  label: { fontFamily: fonts.bodyMedium, fontSize: 10, color: colors.textMuted },
  value: { fontFamily: fonts.displayMedium, fontSize: 20 },
});
