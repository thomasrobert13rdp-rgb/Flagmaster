import { Pressable, StyleSheet, View, type ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { colors, gradients, motion, radii, shadows } from '@/src/theme/tokens';

interface GlassCardProps {
  children: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
  onPress?: () => void;
  glow?: 'none' | 'gold' | 'ocean' | 'coral';
}

const GLOW_SHADOW = {
  none: undefined,
  gold: shadows.glowGold,
  ocean: shadows.glowOcean,
  coral: shadows.glowCoral,
};

export function GlassCard({ children, style, onPress, glow = 'none' }: GlassCardProps) {
  const scale = useSharedValue(1);
  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  const body = (
    <Animated.View
      style={[styles.wrapper, GLOW_SHADOW[glow], onPress ? animatedStyle : undefined, style]}
    >
      <LinearGradient
        colors={gradients.cardBorder}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.borderGradient}
      >
        <BlurView intensity={36} tint="dark" style={styles.blur}>
          <View style={styles.tint} />
          <View style={styles.inner}>{children}</View>
        </BlurView>
      </LinearGradient>
    </Animated.View>
  );

  if (!onPress) return body;

  return (
    <Pressable
      onPress={onPress}
      onPressIn={() => {
        scale.value = withSpring(0.97, motion.spring.press);
      }}
      onPressOut={() => {
        scale.value = withSpring(1, motion.spring.press);
      }}
    >
      {body}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    borderRadius: radii.lg,
    overflow: 'hidden',
  },
  borderGradient: {
    borderRadius: radii.lg,
    padding: 1,
  },
  blur: {
    borderRadius: radii.lg - 1,
    overflow: 'hidden',
  },
  tint: {
    ...StyleSheet.absoluteFill,
    backgroundColor: colors.glass,
  },
  inner: {
    padding: 16,
    borderRadius: radii.lg - 1,
  },
});
