import { useEffect } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useTranslation } from 'react-i18next';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import Svg, { Circle, Defs, LinearGradient as SvgGradient, Stop } from 'react-native-svg';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import type { RankTier } from '@/src/types';
import { colors, fonts, rankGradients, spacing } from '@/src/theme/tokens';
import { rankTierLabelKey } from '@/src/features/progression/rank';

const TIER_ICON: Record<RankTier, keyof typeof FontAwesome.glyphMap> = {
  bronze: 'shield',
  silver: 'shield',
  gold: 'star',
  platinum: 'diamond',
  diamond: 'diamond',
  master: 'fire',
  champion: 'trophy',
};

// Competitive ELO rank badge — not used in duel mode (trophies only there).
interface RankLike {
  tier: RankTier;
  label: string;
  labelKey?: string;
  division?: 1 | 2 | 3;
}

interface RankBadgeProps {
  rank: RankLike;
  elo?: number;
  suffix?: string;
  compact?: boolean;
  size?: number;
}

const ANIMATED_TIERS: RankTier[] = ['champion', 'master'];

export function RankBadge({ rank, elo, suffix, compact, size = compact ? 56 : 88 }: RankBadgeProps) {
  const { t } = useTranslation();
  const gradientColors = rankGradients[rank.tier] ?? rankGradients.bronze;
  const eloSuffix = suffix ?? t('elo');
  const tierLabel = rank.labelKey
    ? `${t(rank.labelKey)}${rank.division ? ` ${rank.division}` : ''}`
    : rank.label;
  const isAnimatedTier = ANIMATED_TIERS.includes(rank.tier);
  const spin = useSharedValue(0);

  useEffect(() => {
    if (isAnimatedTier) {
      spin.value = withRepeat(withTiming(1, { duration: 2600, easing: Easing.linear }), -1, false);
    } else {
      spin.value = 0;
    }
  }, [isAnimatedTier, spin]);

  // Subtle glass "reflection" highlight in the upper-left quadrant. For the
  // top two tiers it sweeps gently instead of sitting static.
  const shineStyle = useAnimatedStyle(() => ({
    opacity: isAnimatedTier ? 0.16 + 0.14 * Math.sin(spin.value * Math.PI * 2) : 0.14,
    transform: [{ rotate: `${spin.value * 360}deg` }],
  }));

  const stroke = Math.max(3, size * 0.06);
  const radius = size / 2 - stroke;
  const gradId = `rankGrad-${rank.tier}`;

  return (
    <View style={styles.container}>
      <View style={{ width: size, height: size }}>
        <Svg width={size} height={size}>
          <Defs>
            <SvgGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="100%">
              <Stop offset="0%" stopColor={gradientColors[0]} />
              <Stop offset="55%" stopColor={gradientColors[1]} />
              <Stop offset="100%" stopColor={gradientColors[2]} />
            </SvgGradient>
          </Defs>
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={`url(#${gradId})`}
            strokeWidth={stroke}
            fill={colors.surfaceElevated}
          />
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius - stroke / 2 - 2}
            fill={colors.surface}
            stroke={colors.border}
            strokeWidth={1}
          />
        </Svg>
        <Animated.View pointerEvents="none" style={[styles.shineWrap, { width: size, height: size }]}>
          <Animated.View
            style={[
              styles.shineOverlay,
              shineStyle,
              { width: size * 0.62, height: size * 0.62, borderRadius: size * 0.31 },
            ]}
          />
        </Animated.View>
        <View style={[StyleSheet.absoluteFill, styles.iconWrap]}>
          <FontAwesome
            name={TIER_ICON[rank.tier] ?? 'shield'}
            size={size * 0.36}
            color={gradientColors[1]}
          />
        </View>
      </View>
      {!compact ? (
        <View style={styles.textWrap}>
          <Text style={[styles.tier, { color: gradientColors[1] }]}>{tierLabel}</Text>
          {elo !== undefined ? (
            <Text style={styles.elo}>
              {elo} {eloSuffix}
            </Text>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  iconWrap: { alignItems: 'center', justifyContent: 'center' },
  shineWrap: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    borderRadius: 999,
  },
  shineOverlay: {
    position: 'absolute',
    top: '-18%',
    left: '-18%',
    backgroundColor: colors.text,
  },
  textWrap: { gap: 2 },
  tier: { fontFamily: fonts.displayMedium, fontSize: 18 },
  elo: { fontFamily: fonts.bodyMedium, fontSize: 12, color: colors.textMuted },
});
