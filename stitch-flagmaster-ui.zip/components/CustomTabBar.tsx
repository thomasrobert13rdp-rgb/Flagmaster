import { Pressable, StyleSheet, Text, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { colors, fonts, gradients, radii, shadows, spacing } from '@/src/theme/tokens';

const ICONS: Record<string, keyof typeof FontAwesome.glyphMap> = {
  index: 'globe',
  ranked: 'trophy',
  duel: 'bolt',
  collection: 'diamond',
  leaderboard: 'list-ol',
  profile: 'user',
};

interface TabBarRoute {
  key: string;
  name: string;
}

interface TabBarProps {
  state: { routes: TabBarRoute[]; index: number };
  descriptors: Record<string, { options: { title?: string } }>;
  navigation: {
    emit: (event: {
      type: 'tabPress';
      target: string;
      canPreventDefault: boolean;
    }) => { defaultPrevented: boolean };
    navigate: (name: string) => void;
  };
}

export function CustomTabBar({ state, descriptors, navigation }: TabBarProps) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.wrapper, { paddingBottom: Math.max(insets.bottom, spacing.sm) }]}>
      <View style={styles.pill}>
        <BlurView intensity={44} tint="dark" style={styles.blur}>
          <View style={styles.tint} />
          {state.routes.map((route, index) => {
            const { options } = descriptors[route.key];
            const focused = state.index === index;
            const label = (options.title ?? route.name) as string;

            const onPress = () => {
              void Haptics.selectionAsync();
              const event = navigation.emit({
                type: 'tabPress',
                target: route.key,
                canPreventDefault: true,
              });
              if (!focused && !event.defaultPrevented) {
                navigation.navigate(route.name);
              }
            };

            return (
              <TabItem
                key={route.key}
                icon={ICONS[route.name] ?? 'circle'}
                label={label}
                focused={focused}
                onPress={onPress}
              />
            );
          })}
        </BlurView>
      </View>
    </View>
  );
}

function TabItem({
  icon,
  label,
  focused,
  onPress,
}: {
  icon: keyof typeof FontAwesome.glyphMap;
  label: string;
  focused: boolean;
  onPress: () => void;
}) {
  const scale = useSharedValue(1);
  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <Pressable
      style={styles.item}
      onPress={onPress}
      onPressIn={() => {
        scale.value = withSpring(0.88, { damping: 12, stiffness: 260 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 8, stiffness: 220 });
      }}
    >
      <Animated.View style={[styles.itemInner, animatedStyle]}>
        {focused ? (
          <LinearGradient
            colors={gradients.gold}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.activeBubble}
          >
            <FontAwesome name={icon} size={18} color={colors.background} />
          </LinearGradient>
        ) : (
          <View style={styles.inactiveBubble}>
            <FontAwesome name={icon} size={18} color={colors.textMuted} />
          </View>
        )}
        <Text style={[styles.label, focused && styles.labelActive]} numberOfLines={1}>
          {label}
        </Text>
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    paddingHorizontal: spacing.md,
  },
  pill: {
    borderRadius: radii.xl,
    overflow: 'hidden',
    width: '100%',
    ...shadows.card,
  },
  blur: {
    flexDirection: 'row',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.xs,
  },
  tint: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(19, 24, 46, 0.78)',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.xl,
  },
  item: { flex: 1, alignItems: 'center' },
  itemInner: { alignItems: 'center', gap: 4, minWidth: 56 },
  activeBubble: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  inactiveBubble: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    fontFamily: fonts.bodyMedium,
    fontSize: 11,
    color: colors.textMuted,
  },
  labelActive: {
    color: colors.gold,
    fontFamily: fonts.bodyBold,
  },
});
