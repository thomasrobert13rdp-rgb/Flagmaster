import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import * as Haptics from 'expo-haptics';
import { colors, fonts, spacing } from '@/src/theme/tokens';

interface ScreenHeaderProps {
  title: string;
  showBack?: boolean;
  onBack?: () => void;
}

export function ScreenHeader({ title, showBack = false, onBack }: ScreenHeaderProps) {
  const router = useRouter();
  const canGoBack = showBack || Boolean(onBack);

  const handleBack = () => {
    void Haptics.selectionAsync();
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  };

  return (
    <View style={styles.row}>
      {canGoBack ? (
        <Pressable onPress={handleBack} style={styles.back} hitSlop={12}>
          <FontAwesome name="chevron-left" size={16} color={colors.text} />
        </Pressable>
      ) : (
        <View style={styles.backPlaceholder} />
      )}
      <Text style={styles.title}>{title}</Text>
      <View style={styles.backPlaceholder} />
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
  back: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.surfaceElevated,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  backPlaceholder: { width: 38 },
  title: { fontFamily: fonts.displayMedium, fontSize: 22, color: colors.text },
});
