import { useEffect } from 'react';
import { StyleSheet, Text } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
} from 'react-native-reanimated';
import { colors, fonts, gradients, spacing } from '@/src/theme/tokens';

interface ComboIndicatorProps {
  combo: number;
}

function tierGradient(combo: number) {
  if (combo >= 8) return gradients.coral;
  if (combo >= 5) return gradients.violet;
  return gradients.ocean;
}

export function ComboIndicator({ combo }: ComboIndicatorProps) {
  const pop = useSharedValue(0);

  useEffect(() => {
    if (combo < 2) return;
    pop.value = 0;
    pop.value = withSequence(
      withSpring(1.15, { damping: 6, stiffness: 260 }),
      withSpring(1, { damping: 10, stiffness: 220 })
    );
  }, [combo, pop]);

  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: pop.value }] }));

  if (combo < 2) return null;

  return (
    <Animated.View style={animatedStyle}>
      <LinearGradient
        colors={tierGradient(combo)}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.container}
      >
        <Text style={styles.text}>🔥 x{combo}</Text>
      </LinearGradient>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: 999,
  },
  text: {
    fontFamily: fonts.displayBold,
    fontSize: 14,
    color: colors.background,
    letterSpacing: 0.3,
  },
});
