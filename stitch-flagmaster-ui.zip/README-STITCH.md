# FlagMaster — export UI pour Stitch

React Native / Expo — pas de CSS ni Tailwind.

## theme/tokens.ts
Design system complet (couleurs, gradients, spacing, fonts, shadows).

## components/
ScreenBackground, ScreenHeader, CustomTabBar, GlassCard, PrimaryButton,
FormatCard, QuizOptionButton, RankBadge, SoloScoreChip, ComboIndicator, ProgressRing

## screens/
RootLayout, TabsLayout, HomeTab, ProfileTab, SoloHub, SoloRun

Polices: Fredoka + Plus Jakarta Sans | Fond #080B18
