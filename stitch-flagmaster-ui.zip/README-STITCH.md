# FlagMaster — export UI pour rework visuel (Stitch)

Stack: React Native / Expo (pas de CSS ni Tailwind).

## Design system
- mobile/src/theme/tokens.ts — couleurs, gradients, spacing, fonts, shadows

## Structure & navigation
- mobile/app/_layout.tsx
- mobile/app/(tabs)/_layout.tsx
- CustomTabBar, ScreenHeader, ScreenBackground

## Composants UI
- GlassCard, PrimaryButton, FormatCard, QuizOptionButton
- RankBadge, SoloScoreChip, ComboIndicator, ProgressRing

## Écrans exemples
- (tabs)/index, (tabs)/profile, solo/index, solo/run

Polices: Fredoka (titres) + Plus Jakarta Sans (corps).
Fond: #080B18 | Accents: teal #1BC8E8, gold #F5B942, coral #FF6B6B.
