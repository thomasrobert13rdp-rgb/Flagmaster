import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import { GlassCard } from '@/src/components/GlassCard';
import { ProgressRing } from '@/src/components/ProgressRing';
import { RankBadge } from '@/src/components/RankBadge';
import { ScreenBackground } from '@/src/components/ScreenBackground';
import { StreakFlame } from '@/src/components/StreakFlame';
import { colors, fonts, gradients, radii, spacing } from '@/src/theme/tokens';
import { quizHref } from '@/src/utils/navigation';
import { soloRoutes } from '@/src/utils/soloNavigation';
import { useGameStore } from '@/src/store/gameStore';
import { xpForLevel } from '@/src/features/progression/rank';

export default function HubScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const profile = useGameStore((s) => s.profile);

  const xpTarget = xpForLevel(profile.level);
  const xpProgress = xpTarget > 0 ? Math.min(1, profile.xp / xpTarget) : 0;

  return (
    <ScreenBackground>
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
          <Animated.View entering={FadeInDown.duration(400)} style={styles.brandRow}>
            <View style={styles.brandCircle}>
              <FontAwesome name="compass" size={22} color={colors.gold} />
            </View>
            <View>
              <Text style={styles.brand}>{t('appName')}</Text>
              <Text style={styles.tagline}>{t('tagline')}</Text>
            </View>
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(450).delay(80)}>
            <GlassCard style={styles.rankCard} glow="gold">
              <View style={styles.rankRow}>
                <ProgressRing
                  progress={xpProgress}
                  size={92}
                  strokeWidth={9}
                  gradient={gradients.gold}
                >
                  <FontAwesome name="star" size={22} color={colors.gold} />
                  <Text style={styles.levelText}>{t('level')} {profile.level}</Text>
                </ProgressRing>

                <View style={styles.rankInfo}>
                  <Text style={styles.section}>{t('yourRank')}</Text>
                  <RankBadge rank={profile.rank} elo={profile.elo} compact />
                </View>
              </View>

              <View style={styles.statsRow}>
                <View style={styles.statItem}>
                  <StreakFlame streak={profile.streak} />
                  <Text style={styles.statLabel}>{t('streak')}</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{profile.xp}</Text>
                  <Text style={styles.statLabel}>{t('xp')}</Text>
                </View>
              </View>
            </GlassCard>
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(450).delay(160)} style={styles.cardsGrid}>
            <GameCard
              title={t('startRanked')}
              subtitle={t('ranked')}
              icon="trophy"
              gradient={gradients.gold}
              onPress={() => router.push('/(tabs)/ranked')}
            />
            <GameCard
              title={t('daily')}
              subtitle={t('dailySeed')}
              icon="calendar"
              gradient={gradients.ocean}
              onPress={() => router.push(quizHref('daily'))}
            />
            <GameCard
              title={t('solo')}
              subtitle={t('soloTagline')}
              icon="graduation-cap"
              gradient={gradients.violet}
              onPress={() => router.push(soloRoutes.hub)}
              wide
            />
          </Animated.View>
        </ScrollView>
      </SafeAreaView>
    </ScreenBackground>
  );
}

function GameCard({
  title,
  subtitle,
  icon,
  gradient,
  onPress,
  wide,
}: {
  title: string;
  subtitle: string;
  icon: keyof typeof FontAwesome.glyphMap;
  gradient: readonly [string, string, string];
  onPress: () => void;
  wide?: boolean;
}) {
  return (
    <Pressable onPress={onPress} style={[styles.gameCardWrap, wide && styles.gameCardWide]}>
      <LinearGradient
        colors={gradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.gameCard}
      >
        <FontAwesome name={icon} size={26} color={colors.background} />
        <View>
          <Text style={styles.gameCardTitle}>{title}</Text>
          <Text style={styles.gameCardSubtitle}>{subtitle}</Text>
        </View>
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  container: { padding: spacing.lg, gap: spacing.md, paddingBottom: 140 },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.xs },
  brandCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.surfaceElevated,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brand: { fontFamily: fonts.displayBold, fontSize: 26, color: colors.text },
  tagline: { fontFamily: fonts.body, fontSize: 13, color: colors.textMuted },
  rankCard: { gap: spacing.md },
  rankRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  levelText: { fontFamily: fonts.bodyBold, fontSize: 11, color: colors.text, marginTop: 2 },
  rankInfo: { flex: 1, gap: spacing.xs },
  section: { fontFamily: fonts.bodyBold, fontSize: 12, letterSpacing: 0.6, color: colors.textMuted },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.sm,
  },
  statItem: { alignItems: 'center', gap: 2 },
  statDivider: { width: 1, height: 28, backgroundColor: colors.border },
  statLabel: { fontFamily: fonts.bodyMedium, fontSize: 11, color: colors.textMuted },
  statValue: { fontFamily: fonts.displayMedium, fontSize: 18, color: colors.text },
  cardsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  gameCardWrap: { width: '48%' },
  gameCardWide: { width: '100%' },
  gameCard: {
    borderRadius: radii.lg,
    padding: spacing.md,
    minHeight: 108,
    justifyContent: 'space-between',
  },
  gameCardTitle: { fontFamily: fonts.displayMedium, fontSize: 16, color: colors.background },
  gameCardSubtitle: { fontFamily: fonts.bodyMedium, fontSize: 12, color: 'rgba(8,11,24,0.7)' },
});
