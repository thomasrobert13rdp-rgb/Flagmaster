import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { FormatCard } from '@/src/components/FormatCard';
import { GlassCard } from '@/src/components/GlassCard';
import { ScreenBackground } from '@/src/components/ScreenBackground';
import { ScreenHeader } from '@/src/components/ScreenHeader';
import { SOLO_FORMATS } from '@/src/features/solo/formats';
import { soloFormatSupportsDifficulty } from '@/src/features/solo/difficulty';
import { buildSoloConfigFromFormat, useGameStore } from '@/src/store/gameStore';
import { soloRoutes } from '@/src/utils/soloNavigation';
import { colors, fonts, gradients, radii, spacing } from '@/src/theme/tokens';
import type { Continent } from '@/src/types';

const CONTINENTS: Array<{ id: Continent; icon: keyof typeof FontAwesome.glyphMap }> = [
  { id: 'europe', icon: 'university' },
  { id: 'africa', icon: 'sun-o' },
  { id: 'asia', icon: 'tree' },
  { id: 'americas', icon: 'globe' },
  { id: 'oceania', icon: 'anchor' },
];

export default function SoloHubScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const soloRecords = useGameStore((s) => s.soloRecords);
  const missions = useGameStore((s) => s.missions);
  const campaignProgress = useGameStore((s) => s.campaignProgress);

  const dailyCompleted = missions.daily.filter((m) => m.completed).length;

  const startFormat = (format: (typeof SOLO_FORMATS)[number]['id']) => {
    if (soloFormatSupportsDifficulty(format)) {
      router.push(soloRoutes.setup(format));
      return;
    }
    const config = buildSoloConfigFromFormat(format);
    useGameStore.getState().startSoloRun(config);
    router.push(soloRoutes.run(format));
  };

  return (
    <ScreenBackground variant="coral">
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
          <ScreenHeader title={t('solo')} showBack />
          <Text style={styles.subtitle}>{t('soloTagline')}</Text>

          <Animated.View entering={FadeInUp.duration(400)}>
            <GlassCard glow="gold" style={styles.teaserCard} onPress={() => router.push(soloRoutes.missions)}>
              <FontAwesome name="tasks" size={20} color={colors.gold} />
              <View style={styles.teaserText}>
                <Text style={styles.teaserTitle}>{t('soloMissions')}</Text>
                <Text style={styles.teaserBody}>
                  {t('soloMissionTeaser', { completed: dailyCompleted, total: missions.daily.length })}
                </Text>
              </View>
              <FontAwesome name="chevron-right" size={14} color={colors.textMuted} />
            </GlassCard>
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(400).delay(100)}>
            <GlassCard glow="ocean" style={styles.teaserCard} onPress={() => router.push(soloRoutes.revision)}>
              <FontAwesome name="repeat" size={20} color={colors.primary} />
              <View style={styles.teaserText}>
                <Text style={styles.teaserTitle}>{t('revision')}</Text>
                <Text style={styles.teaserBody}>{t('revisionTeaser')}</Text>
              </View>
              <FontAwesome name="chevron-right" size={14} color={colors.textMuted} />
            </GlassCard>
          </Animated.View>

          <Text style={styles.section}>{t('soloArcade')}</Text>
          <Animated.View entering={FadeInUp.duration(400).delay(60)} style={styles.formatGrid}>
            {SOLO_FORMATS.map((fmt) => (
              <FormatCard
                key={fmt.id}
                title={t(fmt.labelKey)}
                description={t(fmt.descriptionKey)}
                icon={fmt.icon}
                gradient={fmt.gradient}
                record={soloRecords[fmt.id]}
                recordLabel={fmt.id === 'marathon' ? t('soloMarathonRecord') : t('soloRecord')}
                onPress={() => startFormat(fmt.id)}
              />
            ))}
          </Animated.View>

          <Text style={styles.section}>{t('soloCampaign')}</Text>
          <Animated.View entering={FadeInUp.duration(400).delay(120)}>
            <Pressable onPress={() => router.push(soloRoutes.campaign)}>
              <LinearGradient
                colors={gradients.violet}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.campaignBanner}
              >
                <FontAwesome name="map" size={28} color={colors.background} />
                <View style={styles.campaignText}>
                  <Text style={styles.campaignTitle}>{t('soloCampaign')}</Text>
                  <Text style={styles.campaignDesc}>{t('soloCampaignDesc')}</Text>
                  <Text style={styles.campaignStars}>
                    {t('campaignStars', { count: campaignProgress.totalStars })}
                  </Text>
                </View>
              </LinearGradient>
            </Pressable>
          </Animated.View>

          <Text style={styles.section}>{t('byContinent')}</Text>
          <Animated.View entering={FadeInUp.duration(400).delay(160)} style={styles.continentGrid}>
            {CONTINENTS.map((continent) => (
              <Pressable
                key={continent.id}
                style={styles.continentChip}
                onPress={() => router.push(soloRoutes.setup('classic', { continent: continent.id }))}
              >
                <FontAwesome name={continent.icon} size={16} color={colors.gold} />
                <Text style={styles.continentLabel}>{t(continent.id)}</Text>
              </Pressable>
            ))}
          </Animated.View>
        </ScrollView>
      </SafeAreaView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  container: { padding: spacing.lg, gap: spacing.md, paddingBottom: 60 },
  subtitle: { fontFamily: fonts.body, fontSize: 14, color: colors.textMuted },
  section: { fontFamily: fonts.displayMedium, fontSize: 18, color: colors.text, marginTop: spacing.sm },
  formatGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  teaserCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  teaserText: { flex: 1 },
  teaserTitle: { fontFamily: fonts.bodyBold, fontSize: 15, color: colors.text },
  teaserBody: { fontFamily: fonts.body, fontSize: 12, color: colors.textMuted },
  campaignBanner: {
    borderRadius: radii.lg,
    padding: spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  campaignText: { flex: 1, gap: 4 },
  campaignTitle: { fontFamily: fonts.displayMedium, fontSize: 18, color: colors.background },
  campaignDesc: { fontFamily: fonts.bodyMedium, fontSize: 12, color: 'rgba(8,11,24,0.75)' },
  campaignStars: { fontFamily: fonts.bodyBold, fontSize: 12, color: colors.background },
  continentGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  continentChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radii.full,
    backgroundColor: colors.surfaceElevated,
    borderWidth: 1,
    borderColor: colors.border,
  },
  continentLabel: { fontFamily: fonts.bodyMedium, fontSize: 13, color: colors.text },
});
