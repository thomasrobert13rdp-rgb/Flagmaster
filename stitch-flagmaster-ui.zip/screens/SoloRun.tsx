import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import * as Haptics from 'expo-haptics';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, {
  FadeIn,
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { ComboIndicator } from '@/src/components/ComboIndicator';
import { FlagImage } from '@/src/components/FlagImage';
import { LivesBar } from '@/src/components/LivesBar';
import { MapImage } from '@/src/components/MapImage';
import { QuestionTimer } from '@/src/components/QuestionTimer';
import { QuizOptionButton } from '@/src/components/QuizOptionButton';
import { ScreenBackground } from '@/src/components/ScreenBackground';
import { ScreenHeader } from '@/src/components/ScreenHeader';
import { SoloScoreChip } from '@/src/components/SoloScoreChip';
import { ZoomedFlag } from '@/src/components/ZoomedFlag';
import { playError, playSuccess } from '@/src/features/audio/sounds';
import { buildSoloConfigFromFormat, useGameStore } from '@/src/store/gameStore';
import { usesGlobalTimer } from '@/src/features/solo/formats';
import { SOLO_DIFFICULTY_TIERS, parseSoloDifficultyTier } from '@/src/features/solo/difficulty';
import { soloRoutes } from '@/src/utils/soloNavigation';
import { confirmAction } from '@/src/utils/confirmAction';
import { colors, fonts, radii, spacing } from '@/src/theme/tokens';
import type { Continent, SoloFormat } from '@/src/types';

function parseContinentParam(value: unknown): Continent | undefined {
  if (typeof value !== 'string') return undefined;
  const valid: Continent[] = ['europe', 'africa', 'asia', 'americas', 'oceania'];
  return valid.includes(value as Continent) ? (value as Continent) : undefined;
}

const FORMAT_LABEL_KEYS: Record<SoloFormat, string> = {
  classic: 'soloClassic',
  survival: 'soloSurvival',
  blitz: 'soloBlitz',
  marathon: 'soloMarathon',
  time_attack: 'soloTimeAttack',
  map_flags: 'soloMapFlags',
  capitals: 'soloCapitals',
  revision: 'revision',
  regions: 'soloRegions',
  fiction: 'soloFiction',
  variants: 'soloVariants',
  campaign: 'soloCampaign',
};

export default function SoloRunScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const params = useLocalSearchParams<{
    format?: string;
    stageId?: string;
    continent?: string;
    difficulty?: string;
  }>();

  const activeSolo = useGameStore((s) => s.activeSolo);
  const startSoloRun = useGameStore((s) => s.startSoloRun);
  const answerSolo = useGameStore((s) => s.answerSolo);
  const advanceSoloQuestion = useGameStore((s) => s.advanceSoloQuestion);
  const abandonSoloRun = useGameStore((s) => s.abandonSoloRun);
  const tickSoloGlobalTimer = useGameStore((s) => s.tickSoloGlobalTimer);
  const hapticsEnabled = useGameStore((s) => s.settings.hapticsEnabled);
  const soundEnabled = useGameStore((s) => s.settings.soundEnabled);

  const [selected, setSelected] = useState<string | null>(null);
  const [revealed, setReveal] = useState(false);
  const questionStart = useRef(Date.now());
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const startedRef = useRef(false);
  const advancingRef = useRef(false);
  const flashOpacity = useSharedValue(0);
  const flagScale = useSharedValue(0.9);
  const globalTimerInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  const format = (params.format ?? activeSolo?.config.format ?? 'classic') as SoloFormat;
  const continent = parseContinentParam(params.continent) ?? activeSolo?.config.continent;
  const difficulty =
    parseSoloDifficultyTier(params.difficulty) ?? activeSolo?.config.difficulty;

  const goToResult = useCallback(() => {
    const state = useGameStore.getState();
    if (!state.lastSoloResult) {
      state.finishSoloRun();
    }
    const activeConfig = useGameStore.getState().activeSolo?.config;
    router.replace(
      soloRoutes.result(format, {
        stageId: activeConfig?.campaignStageId ?? params.stageId,
        continent: activeConfig?.continent ?? continent,
        difficulty: activeConfig?.difficulty ?? difficulty,
      })
    );
  }, [format, router, params.stageId, continent, difficulty]);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;

    const existing = useGameStore.getState().activeSolo;
    const configMatches =
      existing &&
      existing.config.format === format &&
      existing.config.continent === continent &&
      existing.config.difficulty === difficulty &&
      (params.stageId
        ? existing.config.campaignStageId === params.stageId
        : !existing.config.campaignStageId);

    if (configMatches) return;

    if (existing) {
      useGameStore.getState().abandonSoloRun();
    }

    const config = buildSoloConfigFromFormat(format, {
      campaignStageId: params.stageId,
      continent,
      difficulty,
    });
    startSoloRun(config);
  }, [format, continent, params.stageId, difficulty, startSoloRun]);

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (globalTimerInterval.current) clearInterval(globalTimerInterval.current);
    };
  }, []);

  useEffect(() => {
    if (!usesGlobalTimer(format)) return;

    globalTimerInterval.current = setInterval(() => {
      tickSoloGlobalTimer(100);
      const state = useGameStore.getState().activeSolo;
      if (state?.ended && !state.awaitingAdvance) {
        goToResult();
      }
    }, 100);

    return () => {
      if (globalTimerInterval.current) clearInterval(globalTimerInterval.current);
    };
  }, [format, tickSoloGlobalTimer, goToResult]);

  const question = activeSolo?.questions[activeSolo.currentIndex];

  useEffect(() => {
    flagScale.value = 0.9;
    flagScale.value = withTiming(1, { duration: 320 });
    questionStart.current = Date.now();
  }, [question?.id, flagScale]);

  const advance = useCallback(() => {
    if (advancingRef.current) return;
    advancingRef.current = true;

    const finished = advanceSoloQuestion();
    const state = useGameStore.getState();

    if (finished || !state.activeSolo) {
      goToResult();
      advancingRef.current = false;
      return;
    }

    setSelected(null);
    setReveal(false);
    advancingRef.current = false;
    questionStart.current = Date.now();
  }, [advanceSoloQuestion, goToResult]);

  const handleAnswer = useCallback(
    async (optionId: string | null) => {
      if (!question || revealed || advancingRef.current) return;
      setSelected(optionId);
      setReveal(true);
      const timeMs = Date.now() - questionStart.current;
      const answer = answerSolo(optionId, timeMs);

      if (answer?.correct) {
        flashOpacity.value = withSequence(
          withTiming(0.16, { duration: 90 }),
          withTiming(0, { duration: 260 })
        );
      } else {
        flashOpacity.value = withSequence(
          withTiming(0.22, { duration: 90 }),
          withTiming(0, { duration: 260 })
        );
      }

      if (hapticsEnabled) {
        void Haptics.notificationAsync(
          answer?.correct
            ? Haptics.NotificationFeedbackType.Success
            : Haptics.NotificationFeedbackType.Error
        );
      }
      if (soundEnabled) {
        void (answer?.correct ? playSuccess() : playError());
      }

      const ended = useGameStore.getState().activeSolo?.ended;
      timeoutRef.current = setTimeout(advance, ended ? 600 : 900);
    },
    [question, revealed, answerSolo, hapticsEnabled, soundEnabled, advance, flashOpacity]
  );

  const handleExpire = useCallback(() => {
    if (!revealed && (question?.timeLimitMs ?? 0) > 0) void handleAnswer(null);
  }, [revealed, handleAnswer, question?.timeLimitMs]);

  useEffect(() => {
    if (format !== 'time_attack' || !question || revealed || question.timeLimitMs <= 0) return;
    const timeout = setTimeout(() => handleExpire(), question.timeLimitMs);
    return () => clearTimeout(timeout);
  }, [format, question?.id, question?.timeLimitMs, revealed, handleExpire]);

  const handleAbandon = useCallback(() => {
    confirmAction(
      t('soloAbandonTitle'),
      t('soloAbandonBody'),
      t('soloAbandonConfirm'),
      () => {
        abandonSoloRun();
        router.back();
      }
    );
  }, [abandonSoloRun, router, t]);

  useFocusEffect(
    useCallback(() => {
      const sub = BackHandler.addEventListener('hardwareBackPress', () => {
        handleAbandon();
        return true;
      });
      return () => sub.remove();
    }, [handleAbandon])
  );

  const flashStyle = useAnimatedStyle(() => ({ opacity: flashOpacity.value }));
  const flagAnimatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: flagScale.value }] }));

  const showLives = format === 'survival';
  const showGlobalTimer = usesGlobalTimer(format);
  const isEndless = format === 'survival' || format === 'blitz' || format === 'time_attack';

  const screenTitle = useMemo(() => {
    const key = FORMAT_LABEL_KEYS[format];
    return key ? t(key) : t('solo');
  }, [format, t]);

  const globalTimerProgress = useMemo(() => {
    if (!activeSolo?.globalTimeRemainingMs || !activeSolo.config.globalTimeMs) return 1;
    return Math.max(0, activeSolo.globalTimeRemainingMs / activeSolo.config.globalTimeMs);
  }, [activeSolo?.globalTimeRemainingMs, activeSolo?.config.globalTimeMs]);

  const difficultyLabel = useMemo(() => {
    if (!difficulty) return null;
    const tier = SOLO_DIFFICULTY_TIERS[difficulty];
    return tier ? t(tier.labelKey) : null;
  }, [difficulty, t]);

  if (!activeSolo || !question) {
    return (
      <ScreenBackground>
        <SafeAreaView style={styles.safe}>
          <ActivityIndicator color={colors.primary} style={styles.loader} />
        </SafeAreaView>
      </ScreenBackground>
    );
  }

  const isFlagPrompt = question.type === 'flag_to_country' || question.type === 'zoomed_flag';
  const isMapPrompt = question.type === 'map_to_flag';
  const isOddOneOut = question.type === 'odd_one_out';
  const showFlagOptions =
    question.type === 'country_to_flag' ||
    question.type === 'capital_to_flag' ||
    question.type === 'map_to_flag' ||
    isOddOneOut;
  const flashColor = revealed && selected === question.correctOptionId ? colors.success : colors.error;

  const timeLeftSec = activeSolo.globalTimeRemainingMs
    ? Math.ceil(activeSolo.globalTimeRemainingMs / 1000)
    : 0;

  const maxLives = activeSolo.config.lives ?? 3;
  const isMarathon = format === 'marathon';
  const marathonTotal = activeSolo.questions.length;
  const showQuestionTimer = question.timeLimitMs > 0 && format !== 'time_attack';

  return (
    <ScreenBackground variant={format === 'survival' ? 'coral' : 'default'}>
      <SafeAreaView style={styles.safe}>
        <Animated.View
          pointerEvents="none"
          style={[StyleSheet.absoluteFill, flashStyle, { backgroundColor: flashColor }]}
        />
        <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
          <ScreenHeader title={screenTitle} showBack onBack={handleAbandon} />
          {difficultyLabel ? (
            <View style={styles.difficultyBadge}>
              <Text style={styles.difficultyBadgeText}>{difficultyLabel}</Text>
            </View>
          ) : null}

          <View style={styles.hud}>
            {isMarathon ? (
              <SoloScoreChip
                label={t('soloFlagsSucceeded')}
                value={`${activeSolo.correctCount}/${marathonTotal}`}
                accent="gold"
              />
            ) : (
              <SoloScoreChip label={t('soloScore')} value={activeSolo.score} accent="gold" />
            )}
            {showLives ? <LivesBar lives={activeSolo.lives} maxLives={maxLives} /> : null}
            {showGlobalTimer ? (
              <SoloScoreChip label={t('soloTimeLeft')} value={`${timeLeftSec}s`} accent="coral" />
            ) : !isMarathon ? (
              <SoloScoreChip
                label={t('soloQuestion')}
                value={
                  isEndless
                    ? activeSolo.correctCount + 1
                    : `${activeSolo.currentIndex + 1}/${activeSolo.questions.length}`
                }
                accent="ocean"
              />
            ) : null}
            <ComboIndicator combo={activeSolo.combo} />
          </View>

          {showGlobalTimer && activeSolo.config.globalTimeMs ? (
            <QuestionTimer
              durationMs={activeSolo.config.globalTimeMs}
              running={!revealed}
              controlledProgress={globalTimerProgress}
              resetKey={`${format}-global`}
            />
          ) : null}
          {showQuestionTimer ? (
            <QuestionTimer
              durationMs={question.timeLimitMs}
              running={!revealed}
              onExpire={handleExpire}
              resetKey={question.id}
            />
          ) : null}

          {isMarathon ? (
            <View style={styles.marathonTrack}>
              <View
                style={[
                  styles.marathonFill,
                  {
                    width: `${Math.min(100, (activeSolo.correctCount / marathonTotal) * 100)}%`,
                  },
                ]}
              />
            </View>
          ) : null}

          <Text style={styles.prompt}>{question.prompt}</Text>

          {isMapPrompt && question.map ? (
            <Animated.View style={[styles.flagWrap, flagAnimatedStyle]} entering={FadeIn}>
              <View style={styles.mapFrame}>
                <MapImage map={question.map} width={220} height={220} />
              </View>
            </Animated.View>
          ) : null}

          {isFlagPrompt && question.asset ? (
            <Animated.View style={[styles.flagWrap, flagAnimatedStyle]} entering={FadeIn}>
              {question.type === 'zoomed_flag' ? (
                <ZoomedFlag
                  asset={question.asset}
                  zoomScale={question.zoomScale}
                  zoomOffset={question.zoomOffset}
                />
              ) : (
                <View style={styles.flagFrame}>
                  <FlagImage asset={question.asset} width={230} height={144} />
                </View>
              )}
            </Animated.View>
          ) : null}

          <View style={styles.options}>
            {question.options.map((option) => (
              <QuizOptionButton
                key={option.id}
                optionId={option.id}
                label={option.label}
                asset={option.asset}
                showLabel={!showFlagOptions}
                selected={selected === option.id}
                revealed={revealed}
                correct={option.id === question.correctOptionId}
                onPress={() => handleAnswer(option.id)}
                disabled={revealed}
              />
            ))}
          </View>
        </ScrollView>
      </SafeAreaView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  container: { flexGrow: 1, padding: spacing.lg, gap: spacing.md, paddingBottom: 40 },
  difficultyBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radii.full,
    backgroundColor: colors.surfaceElevated,
    borderWidth: 1,
    borderColor: colors.border,
  },
  difficultyBadgeText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 12,
    color: colors.textMuted,
  },
  hud: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    gap: spacing.sm,
    justifyContent: 'space-between',
  },
  prompt: {
    fontFamily: fonts.displayMedium,
    fontSize: 22,
    color: colors.text,
    marginTop: spacing.sm,
  },
  flagWrap: { alignItems: 'center', marginVertical: spacing.md },
  flagFrame: {
    borderRadius: radii.lg,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: colors.borderLight,
  },
  mapFrame: {
    borderRadius: radii.lg,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: colors.borderLight,
    padding: spacing.sm,
    backgroundColor: colors.surfaceElevated,
  },
  options: { marginTop: spacing.sm },
  loader: { marginTop: spacing.xxl, flex: 1 },
  marathonTrack: {
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.surfaceElevated,
    overflow: 'hidden',
  },
  marathonFill: {
    height: '100%',
    backgroundColor: colors.violet,
    borderRadius: 2,
  },
});
