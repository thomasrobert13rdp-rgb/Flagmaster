import '@/src/i18n';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { DarkTheme, ThemeProvider } from 'expo-router/react-navigation';
import { Stack, useRouter, useSegments } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';
import {
  useFonts,
  Fredoka_500Medium,
  Fredoka_600SemiBold,
  Fredoka_700Bold,
} from '@expo-google-fonts/fredoka';
import {
  PlusJakartaSans_400Regular,
  PlusJakartaSans_500Medium,
  PlusJakartaSans_600SemiBold,
  PlusJakartaSans_700Bold,
} from '@expo-google-fonts/plus-jakarta-sans';

import { preloadSounds } from '@/src/features/audio/sounds';
import {
  scheduleMissionReadyReminder,
  scheduleStreakReminder,
} from '@/src/features/notifications/streak';
import { DuelInviteListener } from '@/src/components/DuelInviteListener';
import { initAnalytics } from '@/src/features/observability/analytics';
import { initPurchases } from '@/src/features/iap/purchases';
import { ensureAnonymousAuth, syncRemoteProfileToStore } from '@/src/api/match';
import { colors } from '@/src/theme/tokens';
import { useGameStore } from '@/src/store/gameStore';
import { ensureStorageReady } from '@/src/store/storage';
import { initSentry, setUserContext } from '@/src/features/observability/sentry';
import { requestAttIfAvailable } from '@/src/features/observability/att';
import { useDuelStore } from '@/src/store/duelStore';

export { ErrorBoundary } from 'expo-router';

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

const navTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.background,
    card: colors.surface,
    text: colors.text,
    border: colors.border,
    primary: colors.primary,
  },
};

function AuthGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const segments = useSegments();
  const initialize = useGameStore((s) => s.initialize);
  const onboardingComplete = useGameStore((s) => s.onboardingComplete);

  useEffect(() => {
    initSentry();
    void initAnalytics();
    void (async () => {
      await ensureStorageReady();
      initialize();
      useDuelStore.getState().initializeDuel();
      await preloadSounds();
      await scheduleStreakReminder();
      await scheduleMissionReadyReminder();
      await requestAttIfAvailable();
      const userId = await ensureAnonymousAuth();
      if (userId) {
        setUserContext(userId);
        await initPurchases(userId);
        await syncRemoteProfileToStore();
      }
    })();
  }, [initialize]);

  useEffect(() => {
    const inOnboarding = segments[0] === 'onboarding';
    if (!onboardingComplete && !inOnboarding) {
      router.replace('/onboarding');
    }
  }, [onboardingComplete, segments, router]);

  return (
    <>
      <DuelInviteListener />
      {children}
    </>
  );
}

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    Fredoka_500Medium,
    Fredoka_600SemiBold,
    Fredoka_700Bold,
    PlusJakartaSans_400Regular,
    PlusJakartaSans_500Medium,
    PlusJakartaSans_600SemiBold,
    PlusJakartaSans_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded) {
      void SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider value={navTheme}>
        <AuthGate>
          <StatusBar style="light" />
          <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }}>
            <Stack.Screen name="onboarding" />
            <Stack.Screen name="(tabs)" />
            <Stack.Screen name="quiz/[mode]" />
            <Stack.Screen name="result" options={{ presentation: 'modal' }} />
            <Stack.Screen name="training" />
            <Stack.Screen name="solo" />
            <Stack.Screen name="duel" />
            <Stack.Screen name="settings" options={{ presentation: 'modal' }} />
            <Stack.Screen name="privacy" options={{ presentation: 'modal' }} />
            <Stack.Screen name="terms" options={{ presentation: 'modal' }} />
            <Stack.Screen name="how-to-play" options={{ presentation: 'modal' }} />
            <Stack.Screen name="player/[id]" />
            <Stack.Screen name="flagdex" />
          </Stack>
        </AuthGate>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
