import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import {
  CosmeticAvatar,
  CosmeticBanner,
  CosmeticNameplate,
  CosmeticTitle,
} from '@/src/components/CosmeticAvatar';
import { GlassCard } from '@/src/components/GlassCard';
import { PrimaryButton } from '@/src/components/PrimaryButton';
import { ProgressRing } from '@/src/components/ProgressRing';
import { RankBadge } from '@/src/components/RankBadge';
import { ScreenBackground } from '@/src/components/ScreenBackground';
import { COSMETIC_CATALOG } from '@/src/features/duel/cosmetics';
import { colors, fonts, gradients, spacing } from '@/src/theme/tokens';
import { useGameStore } from '@/src/store/gameStore';
import { useDuelStore } from '@/src/store/duelStore';
import { ACHIEVEMENTS } from '@/src/features/solo/achievements';
import { AchievementBadge } from '@/src/components/AchievementBadge';
import { getCountries } from '@/src/data/countries';

export default function ProfileScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const profile = useGameStore((s) => s.profile);
  const countryStats = useGameStore((s) => s.countryStats);
  const soloStats = useGameStore((s) => s.soloStats);
  const achievements = useGameStore((s) => s.achievements);
  const inventory = useDuelStore((s) => s.inventory);

  const achievementCount = Object.values(achievements).filter(Boolean).length;
  const totalCountries = getCountries().length;
  const mastered = Object.values(countryStats).filter((s) => s.mastery >= 4).length;
  const totalSeen = Object.values(countryStats).reduce((sum, s) => sum + s.seen, 0);
  const totalCorrect = Object.values(countryStats).reduce((sum, s) => sum + s.correct, 0);
  const accuracy = totalSeen > 0 ? Math.round((totalCorrect / totalSeen) * 100) : 0;
  const masteryProgress = totalCountries > 0 ? mastered / totalCountries : 0;
  const titleLabel = profile.equippedTitle
    ? t(COSMETIC_CATALOG.find((c) => c.id === profile.equippedTitle)?.labelKey ?? 'titleRookie')
    : null;

  return (
    <ScreenBackground>
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
          <Animated.View entering={FadeInDown.duration(400)} style={styles.header}>
        <View style={styles.bannerWrap}>
          <CosmeticBanner bannerId={profile.equippedBanner} height={80} />
        </View>
            <CosmeticAvatar
              username={profile.username}
              avatarId={profile.equippedAvatar}
              frameId={profile.equippedFrame}
              size={80}
              highlight
            />
            <CosmeticNameplate nameplateId={profile.equippedNameplate}>
              <Text style={styles.title}>{profile.username}</Text>
            </CosmeticNameplate>
            {profile.equippedTitle ? (
              <CosmeticTitle titleId={profile.equippedTitle} label={titleLabel ?? ''} />
            ) : null}
            <RankBadge rank={profile.rank} elo={profile.elo} />
            <Text style={styles.balance}>
              {profile.coins} 🪙 · {profile.gems} 💎
            </Text>
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(450).delay(80)}>
            <PrimaryButton
              label={t('customize')}
              variant="gold"
              icon={<FontAwesome name="paint-brush" size={16} color={colors.background} />}
              onPress={() => router.push('/(tabs)/collection')}
            />
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(450).delay(100)}>
            <GlassCard style={styles.masteryCard} glow="ocean">
              <ProgressRing progress={masteryProgress} size={84} strokeWidth={9} gradient={gradients.ocean}>
                <FontAwesome name="flag" size={18} color={colors.primary} />
                <Text style={styles.masteryValue}>{mastered}</Text>
              </ProgressRing>
              <View style={styles.masteryText}>
                <Text style={styles.masteryTitle}>{t('flagdex')}</Text>
                <Text style={styles.masteryBody}>
                  {mastered}/{totalCountries} {t('flagdexMastered')}
                </Text>
              </View>
            </GlassCard>
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(450).delay(140)}>
            <Text style={styles.sectionTitle}>{t('profileSectionCompetitive')}</Text>
            <View style={styles.statsGrid}>
              <StatTile icon="trophy" label={t('duelTrophies')} value={`${profile.duelRating}`} color={colors.gold} />
              <StatTile icon="shield" label={t('elo')} value={`${profile.elo}`} color={colors.primary} />
              <StatTile icon="bolt" label={t('duelWins')} value={`${profile.duelWins}W`} color={colors.coral} />
              <StatTile icon="star" label={t('rankedWins')} value={`${profile.rankedWins}W`} color={colors.violet} />
            </View>
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(450).delay(180)}>
            <Text style={styles.sectionTitle}>{t('profileSectionSolo')}</Text>
            <View style={styles.statsGrid}>
              <StatTile icon="star" label={t('level')} value={`${profile.level}`} color={colors.gold} />
              <StatTile icon="bolt" label={t('xp')} value={`${profile.xp}`} color={colors.primary} />
              <StatTile icon="fire" label={t('streak')} value={`${profile.streak}`} color={colors.coral} />
              <StatTile icon="bullseye" label={t('accuracy')} value={`${accuracy}%`} color={colors.violet} />
              <StatTile icon="gamepad" label={t('soloRuns')} value={`${soloStats.totalRuns}`} color={colors.primary} />
              <StatTile icon="flash" label={t('bestCombo')} value={`${soloStats.bestCombo}`} color={colors.gold} />
            </View>
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(450).delay(220)}>
            <Text style={styles.sectionTitle}>{t('profileSectionCollection')}</Text>
            <View style={styles.statsGrid}>
              <StatTile icon="diamond" label={t('cosmeticsOwned')} value={`${inventory.length}`} color={colors.gold} />
              <StatTile icon="certificate" label={t('achievements')} value={`${achievementCount}`} color={colors.violet} />
            </View>
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(450).delay(240)}>
            <Text style={styles.sectionTitle}>
              {t('achievements')} ({achievementCount}/{ACHIEVEMENTS.length})
            </Text>
            {ACHIEVEMENTS.filter((a) => achievements[a.id]).map((ach, i) => (
              <Animated.View key={ach.id} entering={FadeInUp.duration(300).delay(i * 30)} style={styles.achWrap}>
                <AchievementBadge
                  icon={ach.icon}
                  title={t(ach.labelKey)}
                  description={t(ach.descriptionKey)}
                  unlocked
                />
              </Animated.View>
            ))}
            {achievementCount === 0 ? (
              <Text style={styles.achEmpty}>{t('achievementsEmpty')}</Text>
            ) : null}
          </Animated.View>

          <Animated.View entering={FadeInUp.duration(450).delay(260)} style={styles.actions}>
            <PrimaryButton
              label={t('saveProgress')}
              variant="ocean"
              icon={<FontAwesome name="cloud" size={16} color={colors.background} />}
              onPress={() => router.push('/settings')}
            />
            <PrimaryButton
              label={t('flagdex')}
              variant="ghost"
              icon={<FontAwesome name="book" size={16} color={colors.text} />}
              onPress={() => router.push('/flagdex')}
            />
            <PrimaryButton
              label={t('settings')}
              variant="ghost"
              icon={<FontAwesome name="cog" size={16} color={colors.text} />}
              onPress={() => router.push('/settings')}
            />
          </Animated.View>
        </ScrollView>
      </SafeAreaView>
    </ScreenBackground>
  );
}

function StatTile({
  icon,
  label,
  value,
  color,
}: {
  icon: keyof typeof FontAwesome.glyphMap;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <GlassCard style={styles.statTile}>
      <View style={[styles.statIconWrap, { backgroundColor: `${color}26` }]}>
        <FontAwesome name={icon} size={16} color={color} />
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </GlassCard>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  container: { padding: spacing.lg, gap: spacing.md, paddingBottom: 140 },
  header: { alignItems: 'center', gap: spacing.sm, width: '100%' },
  bannerWrap: { width: '100%' },
  title: { fontFamily: fonts.displayBold, fontSize: 24, color: colors.text },
  balance: { fontFamily: fonts.bodyBold, fontSize: 15, color: colors.gold, marginTop: 4 },
  sectionTitle: { fontFamily: fonts.displayMedium, fontSize: 16, color: colors.text, marginBottom: 4 },
  masteryCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  masteryValue: { fontFamily: fonts.displayBold, fontSize: 16, color: colors.text, marginTop: 2 },
  masteryText: { flex: 1, gap: 2 },
  masteryTitle: { fontFamily: fonts.bodyBold, fontSize: 16, color: colors.text },
  masteryBody: { fontFamily: fonts.body, fontSize: 13, color: colors.textMuted },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  statTile: { width: '47%', alignItems: 'center', gap: 4 },
  statIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 2,
  },
  statValue: { fontFamily: fonts.displayMedium, fontSize: 20, color: colors.text },
  statLabel: { fontFamily: fonts.bodyMedium, fontSize: 12, color: colors.textMuted },
  actions: { gap: spacing.sm, marginTop: spacing.sm },
  achWrap: { marginBottom: spacing.xs },
  achEmpty: { fontFamily: fonts.body, fontSize: 13, color: colors.textMuted },
});
