import { Tabs } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { CustomTabBar } from '@/src/components/CustomTabBar';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function renderTabBar(props: any) {
  return <CustomTabBar {...props} />;
}

export default function TabLayout() {
  const { t } = useTranslation();

  return (
    <Tabs
      screenOptions={{ headerShown: false }}
      tabBar={renderTabBar}
    >
      <Tabs.Screen name="index" options={{ title: t('play') }} />
      <Tabs.Screen name="ranked" options={{ title: t('ranked') }} />
      <Tabs.Screen name="duel" options={{ title: t('duel') }} />
      <Tabs.Screen name="collection" options={{ title: t('collection') }} />
      <Tabs.Screen name="leaderboard" options={{ title: t('leaderboard') }} />
      <Tabs.Screen name="profile" options={{ title: t('profile') }} />
    </Tabs>
  );
}
