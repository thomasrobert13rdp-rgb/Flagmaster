import type { RankTier } from '@/src/types';

/**
 * "Atlas Explorer" design language: a premium midnight-map backdrop with
 * passport-gold reward accents, ocean-teal progression accents and a
 * coral energy accent for combos/duels.
 */
export const colors = {
  // Base "night map" surfaces
  background: '#080B18',
  backgroundAlt: '#0D1226',
  surface: '#141A30',
  surfaceElevated: '#1B2242',
  surfaceHigh: '#232C52',
  border: '#2A3355',
  borderLight: '#3A4570',

  // Brand accents
  primary: '#1BC8E8', // ocean/progress
  primaryMuted: '#0E92AC',
  gold: '#F5B942', // passport-stamp reward accent
  goldMuted: '#C4922B',
  coral: '#FF6B6B', // energy / combo / duel
  coralMuted: '#D94F4F',
  violet: '#8B7CFF', // secondary accent for special moments

  // Semantic
  success: '#2FD675',
  error: '#FF5C6E',
  warning: '#FFB020',

  // Text
  text: '#F7F9FF',
  textMuted: '#9AA6C7',
  textDim: '#5F6B93',

  // Rank medal palette
  bronze: '#D08A4F',
  silver: '#C9D2E8',
  championGold: '#FFD968',

  glass: 'rgba(20, 26, 48, 0.72)',
  glassLight: 'rgba(255, 255, 255, 0.06)',
  overlay: 'rgba(4, 6, 16, 0.6)',
};

export const gradients = {
  // Deep night-map background with a subtle indigo->navy sweep
  background: ['#0A0E20', '#080B18', '#05070F'] as const,
  // "Aurora" blobs floating behind content
  auroraTeal: ['rgba(27, 200, 232, 0.35)', 'rgba(27, 200, 232, 0)'] as const,
  auroraGold: ['rgba(245, 185, 66, 0.28)', 'rgba(245, 185, 66, 0)'] as const,
  auroraCoral: ['rgba(255, 107, 107, 0.24)', 'rgba(255, 107, 107, 0)'] as const,

  gold: ['#FFD968', '#F5B942', '#C4922B'] as const,
  ocean: ['#5EE7E0', '#1BC8E8', '#0E92AC'] as const,
  coral: ['#FF9A6B', '#FF6B6B', '#D94F4F'] as const,
  violet: ['#B2A6FF', '#8B7CFF', '#6656D9'] as const,

  card: ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.02)'] as const,
  cardBorder: ['rgba(255,255,255,0.35)', 'rgba(255,255,255,0)'] as const,

  success: ['#6BE79A', '#2FD675', '#1FAE5B'] as const,
  error: ['#FF8A96', '#FF5C6E', '#D93F51'] as const,
};

export const rankGradients: Record<RankTier, readonly [string, string, string]> = {
  bronze: ['#E7B27E', '#D08A4F', '#9C5F2E'],
  silver: ['#F1F5FF', '#C9D2E8', '#8D9AC2'],
  gold: ['#FFD968', '#F5B942', '#C4922B'],
  platinum: ['#B7F3EE', '#5EE7E0', '#1BC8E8'],
  diamond: ['#D9D2FF', '#8B7CFF', '#6656D9'],
  master: ['#FFB0CB', '#FF6B9D', '#D94577'],
  champion: ['#FFF3C4', '#FFD968', '#F5B942'],
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radii = {
  sm: 10,
  md: 16,
  lg: 22,
  xl: 28,
  full: 999,
};

export const fonts = {
  display: 'Fredoka_600SemiBold',
  displayBold: 'Fredoka_700Bold',
  displayMedium: 'Fredoka_500Medium',
  body: 'PlusJakartaSans_400Regular',
  bodyMedium: 'PlusJakartaSans_500Medium',
  bodySemiBold: 'PlusJakartaSans_600SemiBold',
  bodyBold: 'PlusJakartaSans_700Bold',
};

export const typography = {
  hero: { fontSize: 34, fontFamily: fonts.displayBold, color: colors.text },
  title: { fontSize: 24, fontFamily: fonts.displayMedium, color: colors.text },
  subtitle: { fontSize: 18, fontFamily: fonts.bodySemiBold, color: colors.text },
  body: { fontSize: 16, fontFamily: fonts.body, color: colors.text },
  bodyMedium: { fontSize: 16, fontFamily: fonts.bodyMedium, color: colors.text },
  caption: { fontSize: 13, fontFamily: fonts.bodyMedium, color: colors.textMuted },
  label: {
    fontSize: 12,
    fontFamily: fonts.bodyBold,
    letterSpacing: 0.8,
    color: colors.textMuted,
  },
  score: { fontSize: 64, fontFamily: fonts.displayBold, color: colors.text },
};

export const shadows = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 10,
  },
  glowGold: {
    shadowColor: colors.gold,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 16,
    elevation: 8,
  },
  glowOcean: {
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 16,
    elevation: 8,
  },
  glowCoral: {
    shadowColor: colors.coral,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 16,
    elevation: 8,
  },
};

export const motion = {
  spring: {
    press: { damping: 14, stiffness: 260, mass: 0.6 },
    bouncy: { damping: 9, stiffness: 180, mass: 0.7 },
    gentle: { damping: 18, stiffness: 140, mass: 0.9 },
  },
  duration: {
    fast: 180,
    base: 320,
    slow: 520,
    cinematic: 900,
  },
};
